package com.facul.trabalhofinal;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;

public class LancamentoDialog extends JDialog {

    private final ControleDeDados controle;
    private final boolean receita;

    private final JTextField txtDescricao = new JTextField(25);
    private final JTextField txtValor = new JTextField(10);
    private final JComboBox<String> comboCategoria = new JComboBox<>();
    private final JSpinner spinnerData = new JSpinner(new SpinnerDateModel());

    public LancamentoDialog(JFrame parent, ControleDeDados controle, boolean receita) {
        super(parent, receita ? "Adicionar Receita" : "Adicionar Despesa", true);
        this.controle = controle;
        this.receita = receita;

        setSize(500, 300);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        carregarCategorias();
        spinnerData.setEditor(new JSpinner.DateEditor(spinnerData, "dd/MM/yyyy"));

        add(criarFormulario(), BorderLayout.CENTER);
        add(criarBotoes(), BorderLayout.SOUTH);
    }

    private JPanel criarFormulario() {
        JPanel painel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 6, 6, 6);
        c.fill = GridBagConstraints.HORIZONTAL;

        c.gridx = 0;
        c.gridy = 0;
        painel.add(new JLabel("Descrição (máx. 60):"), c);

        c.gridx = 1;
        c.gridy = 0;
        c.gridwidth = 2;
        painel.add(txtDescricao, c);

        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 1;
        painel.add(new JLabel("Categoria:"), c);

        c.gridx = 1;
        c.gridy = 1;
        painel.add(comboCategoria, c);

        JButton btnNovaCategoria = new JButton("Adicionar categoria");
        btnNovaCategoria.addActionListener(e -> adicionarCategoria());
        c.gridx = 2;
        c.gridy = 1;
        painel.add(btnNovaCategoria, c);

        c.gridx = 0;
        c.gridy = 2;
        painel.add(new JLabel("Valor:"), c);

        c.gridx = 1;
        c.gridy = 2;
        c.gridwidth = 2;
        painel.add(txtValor, c);

        c.gridx = 0;
        c.gridy = 3;
        c.gridwidth = 1;
        painel.add(new JLabel("Data:"), c);

        c.gridx = 1;
        c.gridy = 3;
        c.gridwidth = 2;
        painel.add(spinnerData, c);

        return painel;
    }

    private JPanel criarBotoes() {
        JPanel painel = new JPanel();
        JButton btnSalvar = new JButton("Salvar");
        JButton btnCancelar = new JButton("Cancelar");

        btnSalvar.addActionListener(e -> salvarLancamento());
        btnCancelar.addActionListener(e -> dispose());

        painel.add(btnSalvar);
        painel.add(btnCancelar);
        return painel;
    }

    private void carregarCategorias() {
        comboCategoria.removeAllItems();
        for (String categoria : receita ? controle.getCategoriasReceitas() : controle.getCategoriasDespesas()) {
            comboCategoria.addItem(categoria);
        }
    }

    private void adicionarCategoria() {
        String nova = JOptionPane.showInputDialog(
                this,
                "Nova categoria (máx. 25 caracteres):",
                "Adicionar categoria",
                JOptionPane.PLAIN_MESSAGE
        );

        if (nova == null) {
            return;
        }

        nova = SanitizeFields.categoria(nova);

        if (nova.isBlank()) {
            JOptionPane.showMessageDialog(this, "Categoria inválida.");
            return;
        }

        try {
            if (receita) {
                controle.adicionarCategoriaReceita(nova);
            } else {
                controle.adicionarCategoriaDespesa(nova);
            }
            comboCategoria.addItem(nova);
            comboCategoria.setSelectedItem(nova);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void salvarLancamento() {
        try {
            String descricao = SanitizeFields.descricao(txtDescricao.getText());
            String categoria = SanitizeFields.categoria((String) comboCategoria.getSelectedItem());
            double valor = SanitizeFields.valor(Double.parseDouble(txtValor.getText().replace(',', '.')));
            LocalDate data = converterData((Date) spinnerData.getValue());

            if (descricao.isBlank()) {
                descricao = receita ? "Lancamento Receita" : "Lancamento Despesa";
            }

            if (valor <= 0) {
                throw new IllegalArgumentException("Valor inválido");
            }

            if (receita) {
                controle.adicionarLancamento(new Receita(descricao, categoria, valor, data));
            } else {
                controle.adicionarLancamento(new Despesa(descricao, categoria, valor, data));
            }

            dispose();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Valor inválido. Digite um número válido.");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private LocalDate converterData(Date data) {
        return data.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
}
