package com.facul.trabalhofinal;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class MainFrame extends JFrame {

    private final CarregarDados dados;
    private final ControleDeDados controle;
    private final JPanel painelCentral;

    public MainFrame(CarregarDados dados) {
        this.dados = dados;
        this.controle = new ControleDeDados(dados);
        this.painelCentral = new JPanel(new BorderLayout());

        setTitle("Ez Finance");
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLayout(new BorderLayout());

        add(criarMenu(), BorderLayout.WEST);
        add(painelCentral, BorderLayout.CENTER);
        mostrarBoasVindas();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int resposta = JOptionPane.showConfirmDialog(
                        MainFrame.this,
                        "Deseja salvar os dados antes de sair?",
                        "Sair",
                        JOptionPane.YES_NO_CANCEL_OPTION
                );

                if (resposta == JOptionPane.CANCEL_OPTION || resposta == JOptionPane.CLOSED_OPTION) {
                    return;
                }

                if (resposta == JOptionPane.YES_OPTION) {
                    salvarDados();
                }

                dispose();
                System.exit(0);
            }
        });
    }

    private JPanel criarMenu() {
        JPanel menu = new JPanel(new GridLayout(8, 1, 5, 5));

        JButton btnAddReceita = new JButton("Adicionar Receita");
        JButton btnAddDespesa = new JButton("Adicionar Despesa");
        JButton btnListReceitas = new JButton("Listar Receitas");
        JButton btnListDespesas = new JButton("Listar Despesas");
        JButton btnExtrato = new JButton("Extrato");
        JButton btnSaldo = new JButton("Saldo");
        JButton btnSalvar = new JButton("Salvar");
        JButton btnInicio = new JButton("Início");

        btnAddReceita.addActionListener(e -> abrirLancamento(true));
        btnAddDespesa.addActionListener(e -> abrirLancamento(false));
        btnListReceitas.addActionListener(e -> trocarPainel(new LancamentosPanel(controle, true)));
        btnListDespesas.addActionListener(e -> trocarPainel(new LancamentosPanel(controle, false)));
        btnExtrato.addActionListener(e -> trocarPainel(new ExtratoPanel(controle)));
        btnSaldo.addActionListener(e -> new SaldoDialog(this, controle).setVisible(true));
        btnSalvar.addActionListener(e -> salvarDados());
        btnInicio.addActionListener(e -> mostrarBoasVindas());

        menu.add(btnAddReceita);
        menu.add(btnAddDespesa);
        menu.add(btnListReceitas);
        menu.add(btnListDespesas);
        menu.add(btnExtrato);
        menu.add(btnSaldo);
        menu.add(btnSalvar);
        menu.add(btnInicio);

        return menu;
    }

    private void abrirLancamento(boolean receita) {
        LancamentoDialog dialog = new LancamentoDialog(this, controle, receita);
        dialog.setVisible(true);
    }

    private void salvarDados() {
        new SalvarDados(dados);
        JOptionPane.showMessageDialog(this, "Dados salvos com sucesso.");
    }

    private void mostrarBoasVindas() {
        JPanel painel = new JPanel(new BorderLayout());
        JLabel titulo = new JLabel("Ez Finance", SwingConstants.CENTER);
        JLabel subtitulo = new JLabel("Escolha uma opção no menu lateral.", SwingConstants.CENTER);

        painel.add(titulo, BorderLayout.CENTER);
        painel.add(subtitulo, BorderLayout.SOUTH);
        trocarPainel(painel);
    }

    private void trocarPainel(JPanel novoPainel) {
        painelCentral.removeAll();
        painelCentral.add(novoPainel, BorderLayout.CENTER);
        painelCentral.revalidate();
        painelCentral.repaint();
    }
}
