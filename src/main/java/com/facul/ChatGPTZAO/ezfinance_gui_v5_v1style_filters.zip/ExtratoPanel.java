package com.facul.trabalhofinal;

import java.awt.BorderLayout;
import java.time.YearMonth;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ExtratoPanel extends JPanel {

    private final ControleDeDados controle;
    private final DefaultTableModel modelo;

    public ExtratoPanel(ControleDeDados controle) {
        this.controle = controle;
        this.modelo = new DefaultTableModel(new Object[]{"Data", "Descrição", "Categoria", "Valor", "Saldo"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        setLayout(new BorderLayout());
        add(new JScrollPane(new JTable(modelo)), BorderLayout.CENTER);
        carregarExtrato();
    }

    private void carregarExtrato() {
        modelo.setRowCount(0);

        ArrayList<Lancamento> todos = SortFilters.sortByDate(
                controle.getDespesas(),
                controle.getReceitas()
        );

        double saldo = 0.0;
        double balancoMes = 0.0;
        YearMonth mesAtual = null;

        for (Lancamento l : todos) {
            YearMonth mesLancamento = YearMonth.from(l.getDate());

            if (mesAtual != null && !mesAtual.equals(mesLancamento)) {
                adicionarLinhaFechamentoMes(mesAtual, balancoMes, saldo);
                balancoMes = 0.0;
            }

            mesAtual = mesLancamento;
            saldo += l.getValor();
            balancoMes += l.getValor();

            modelo.addRow(new Object[]{
                l.getDate(),
                l.getDescricao(),
                categoriaDe(l),
                l.getValor(),
                SanitizeFields.valor(saldo)
            });
        }

        if (mesAtual != null) {
            adicionarLinhaFechamentoMes(mesAtual, balancoMes, saldo);
        }
    }

    private void adicionarLinhaFechamentoMes(YearMonth mes, double balancoMes, double saldo) {
        modelo.addRow(new Object[]{
            mes.toString(),
            "BALANÇO DO MÊS",
            "-",
            SanitizeFields.valor(balancoMes),
            SanitizeFields.valor(saldo)
        });
    }

    private String categoriaDe(Lancamento l) {
        if (l instanceof Receita) {
            return ((Receita) l).getCategoria();
        }
        if (l instanceof Despesa) {
            return ((Despesa) l).getCategoria();
        }
        return "-";
    }
}
