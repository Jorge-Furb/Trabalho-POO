package com.facul.trabalhofinal;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;

public class SaldoDialog extends JDialog {

    private final ControleDeDados controle;

    private final JRadioButton rbAtual = new JRadioButton("Saldo atual", true);
    private final JRadioButton rbFiltros = new JRadioButton("Usar filtros");
    private final JSpinner dataInicio = new JSpinner(new SpinnerDateModel());
    private final JSpinner dataFim = new JSpinner(new SpinnerDateModel());
    private final JPanel painelCategorias = new JPanel(new GridLayout(0, 1));

    public SaldoDialog(JFrame parent, ControleDeDados controle) {
        super(parent, "Saldo", true);
        this.controle = controle;

        setSize(450, 500);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        dataInicio.setEditor(new JSpinner.DateEditor(dataInicio, "dd/MM/yyyy"));
        dataFim.setEditor(new JSpinner.DateEditor(dataFim, "dd/MM/yyyy"));

        carregarCategorias();
        add(criarTopo(), BorderLayout.NORTH);
        add(new JScrollPane(painelCategorias), BorderLayout.CENTER);
        add(criarBotoes(), BorderLayout.SOUTH);
    }

    private JPanel criarTopo() {
        JPanel painel = new JPanel(new GridLayout(0, 1, 4, 4));
        ButtonGroup grupo = new ButtonGroup();
        grupo.add(rbAtual);
        grupo.add(rbFiltros);

        painel.add(rbAtual);
        painel.add(rbFiltros);
        painel.add(new JLabel("Data inicial para filtros:"));
        painel.add(dataInicio);
        painel.add(new JLabel("Data final para filtros:"));
        painel.add(dataFim);
        painel.add(new JLabel("Categorias para filtros:"));

        return painel;
    }

    private JPanel criarBotoes() {
        JPanel painel = new JPanel();
        JButton calcular = new JButton("Calcular");
        JButton fechar = new JButton("Fechar");

        calcular.addActionListener(e -> calcularSaldo());
        fechar.addActionListener(e -> dispose());

        painel.add(calcular);
        painel.add(fechar);
        return painel;
    }

    private void carregarCategorias() {
        painelCategorias.removeAll();

        for (String c : controle.getCategoriasReceitas()) {
            painelCategorias.add(new JCheckBox(c, true));
        }
        for (String c : controle.getCategoriasDespesas()) {
            painelCategorias.add(new JCheckBox(c, true));
        }
    }

    private void calcularSaldo() {
        ArrayList<Lancamento> lista = SortFilters.sortByDate(
                controle.getDespesas(),
                controle.getReceitas()
        );

        if (rbAtual.isSelected()) {
            lista = ExclusionFilters.filterByDate(
                    lista,
                    LocalDate.of(1900, 1, 1),
                    LocalDate.now()
            );
        } else {
            LocalDate inicio = converterData((Date) dataInicio.getValue());
            LocalDate fim = converterData((Date) dataFim.getValue());
            lista = ExclusionFilters.filterByDate(lista, inicio, fim);

            ArrayList<String> categorias = categoriasSelecionadas();
            if (!categorias.isEmpty()) {
                lista = ExclusionFilters.filterByCategoria(lista, categorias);
            }
        }

        double saldo = SanitizeFields.valor(controle.balanco(lista));
        JOptionPane.showMessageDialog(this, "Saldo: " + saldo);
    }

    private ArrayList<String> categoriasSelecionadas() {
        ArrayList<String> selecionadas = new ArrayList<>();
        for (int i = 0; i < painelCategorias.getComponentCount(); i++) {
            if (painelCategorias.getComponent(i) instanceof JCheckBox) {
                JCheckBox check = (JCheckBox) painelCategorias.getComponent(i);
                if (check.isSelected()) {
                    selecionadas.add(check.getText());
                }
            }
        }
        return selecionadas;
    }

    private LocalDate converterData(Date data) {
        return data.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
}
