package com.facul.trabalhofinal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

public class MainFrame extends JFrame {

    private final CarregarDados dados;
    private final ControleDeDados controle;

    private final JLabel lblReceitas = new JLabel("Receitas: 0.00");
    private final JLabel lblDespesas = new JLabel("Despesas: 0.00");
    private final JLabel lblLiquido = new JLabel("Líquido: 0.00");

    private final JPanel painelConteudo = new JPanel(new BorderLayout());
    private final JPanel painelCategoriasReceitas = new JPanel();
    private final JPanel painelCategoriasDespesas = new JPanel();

    private final JSpinner dataInicial = criarDateSpinner(LocalDate.of(1900, 1, 1));
    private final JSpinner dataFinal = criarDateSpinner(LocalDate.now());

    public MainFrame() {
        this(new CarregarDados());
    }

    public MainFrame(CarregarDados dados) {
        this.dados = dados;
        this.controle = new ControleDeDados(dados);

        setTitle("Ez Finance");
        setSize(950, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        add(criarMenu(), BorderLayout.WEST);
        add(criarTopo(), BorderLayout.NORTH);
        add(painelConteudo, BorderLayout.CENTER);
        add(criarPainelFiltros(), BorderLayout.EAST);

        painelConteudo.add(new JLabel("Escolha uma opção no menu.", SwingConstants.CENTER), BorderLayout.CENTER);

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                int opcao = JOptionPane.showConfirmDialog(
                        MainFrame.this,
                        "Deseja salvar os dados antes de sair?",
                        "Sair",
                        JOptionPane.YES_NO_CANCEL_OPTION
                );

                if (opcao == JOptionPane.CANCEL_OPTION) {
                    return;
                }

                if (opcao == JOptionPane.YES_OPTION) {
                    new SalvarDados(dados);
                }

                dispose();
                System.exit(0);
            }
        });

        atualizarTudo();
    }

    private JPanel criarMenu() {
        JPanel menu = new JPanel(new GridLayout(8, 1, 5, 5));
        menu.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        menu.setPreferredSize(new Dimension(220, 0));

        JButton btnAddReceita = new JButton("Adicionar Receita");
        JButton btnAddDespesa = new JButton("Adicionar Despesa");
        JButton btnListarReceitas = new JButton("Listar Receitas");
        JButton btnListarDespesas = new JButton("Listar Despesas");
        JButton btnExtrato = new JButton("Extrato detalhado");
        JButton btnSalvar = new JButton("Salvar agora");

        btnAddReceita.addActionListener(e -> abrirDialogLancamento(true));
        btnAddDespesa.addActionListener(e -> abrirDialogLancamento(false));
        btnListarReceitas.addActionListener(e -> listarReceitas());
        btnListarDespesas.addActionListener(e -> listarDespesas());
        btnExtrato.addActionListener(e -> new ExtratoFrame(controle).setVisible(true));
        btnSalvar.addActionListener(e -> {
            new SalvarDados(dados);
            JOptionPane.showMessageDialog(this, "Dados salvos com sucesso.");
        });

        menu.add(btnAddReceita);
        menu.add(btnAddDespesa);
        menu.add(btnListarReceitas);
        menu.add(btnListarDespesas);
        menu.add(btnExtrato);
        menu.add(btnSalvar);

        return menu;
    }

    private JPanel criarTopo() {
        JPanel topo = new JPanel(new BorderLayout());

        JLabel titulo = new JLabel("Ez Finance", SwingConstants.CENTER);
        titulo.setFont(titulo.getFont().deriveFont(24f));
        topo.add(titulo, BorderLayout.NORTH);

        JPanel resumo = new JPanel(new GridLayout(1, 3, 10, 10));
        resumo.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        resumo.add(lblReceitas);
        resumo.add(lblDespesas);
        resumo.add(lblLiquido);

        topo.add(resumo, BorderLayout.CENTER);
        return topo;
    }

    private JPanel criarPainelFiltros() {
        JPanel filtros = new JPanel();
        filtros.setLayout(new BoxLayout(filtros, BoxLayout.Y_AXIS));
        filtros.setBorder(BorderFactory.createTitledBorder("Filtros"));
        filtros.setPreferredSize(new Dimension(270, 0));

        JPanel datas = new JPanel(new GridLayout(4, 1, 5, 5));
        datas.setBorder(BorderFactory.createTitledBorder("Intervalo"));
        datas.add(new JLabel("Data inicial:"));
        datas.add(dataInicial);
        datas.add(new JLabel("Data final:"));
        datas.add(dataFinal);

        painelCategoriasReceitas.setLayout(new BoxLayout(painelCategoriasReceitas, BoxLayout.Y_AXIS));
        painelCategoriasReceitas.setBorder(BorderFactory.createTitledBorder("Categorias Receita"));

        painelCategoriasDespesas.setLayout(new BoxLayout(painelCategoriasDespesas, BoxLayout.Y_AXIS));
        painelCategoriasDespesas.setBorder(BorderFactory.createTitledBorder("Categorias Despesa"));

        filtros.add(datas);
        filtros.add(new JScrollPane(painelCategoriasReceitas));
        filtros.add(new JScrollPane(painelCategoriasDespesas));

        return filtros;
    }

    private void abrirDialogLancamento(boolean receita) {
        LancamentoDialog dialog = new LancamentoDialog(this, controle, receita);
        dialog.setVisible(true);
        atualizarTudo();
    }

    private void listarReceitas() {
        ArrayList<Receita> lista = controle.getReceitas();
        lista = ExclusionFilters.filterByDate(lista, getDataInicial(), getDataFinal());
        lista = ExclusionFilters.filterByCategoria(lista, getCategoriasReceitasSelecionadas());
        lista = SortFilters.sortByDate(lista);

        mostrarPainel(new LancamentoTablePanel(lista));
    }

    private void listarDespesas() {
        ArrayList<Despesa> lista = controle.getDespesas();
        lista = ExclusionFilters.filterByDate(lista, getDataInicial(), getDataFinal());
        lista = ExclusionFilters.filterByCategoria(lista, getCategoriasDespesasSelecionadas());
        lista = SortFilters.sortByDate(lista);

        mostrarPainel(new LancamentoTablePanel(lista));
    }

    private void mostrarPainel(JPanel painel) {
        painelConteudo.removeAll();
        painelConteudo.add(painel, BorderLayout.CENTER);
        painelConteudo.revalidate();
        painelConteudo.repaint();
    }

    private void atualizarTudo() {
        atualizarResumo();
        atualizarCheckboxCategorias();
    }

    private void atualizarResumo() {
        ArrayList<Receita> receitasFiltradas = ExclusionFilters.filterByDate(
                controle.getReceitas(), getDataInicial(), getDataFinal());
        receitasFiltradas = ExclusionFilters.filterByCategoria(
                receitasFiltradas, getCategoriasReceitasSelecionadas());

        ArrayList<Despesa> despesasFiltradas = ExclusionFilters.filterByDate(
                controle.getDespesas(), getDataInicial(), getDataFinal());
        despesasFiltradas = ExclusionFilters.filterByCategoria(
                despesasFiltradas, getCategoriasDespesasSelecionadas());

        double totalReceitas = 0;
        for (Receita r : receitasFiltradas) {
            totalReceitas += r.getValor();
        }

        double totalDespesas = 0;
        for (Despesa d : despesasFiltradas) {
            totalDespesas += d.getValor();
        }

        lblReceitas.setText(String.format("Receitas: %.2f", totalReceitas));
        lblDespesas.setText(String.format("Despesas: %.2f", totalDespesas));
        lblLiquido.setText(String.format("Líquido: %.2f", totalReceitas + totalDespesas));
    }

    private void atualizarCheckboxCategorias() {
        painelCategoriasReceitas.removeAll();
        for (String categoria : controle.getCategoriasReceitas()) {
            JCheckBox cb = new JCheckBox(categoria, true);
            cb.addActionListener(e -> atualizarResumo());
            painelCategoriasReceitas.add(cb);
        }

        painelCategoriasDespesas.removeAll();
        for (String categoria : controle.getCategoriasDespesas()) {
            JCheckBox cb = new JCheckBox(categoria, true);
            cb.addActionListener(e -> atualizarResumo());
            painelCategoriasDespesas.add(cb);
        }

        painelCategoriasReceitas.revalidate();
        painelCategoriasReceitas.repaint();
        painelCategoriasDespesas.revalidate();
        painelCategoriasDespesas.repaint();
        atualizarResumo();
    }

    private ArrayList<String> getCategoriasReceitasSelecionadas() {
        return getCategoriasSelecionadas(painelCategoriasReceitas);
    }

    private ArrayList<String> getCategoriasDespesasSelecionadas() {
        return getCategoriasSelecionadas(painelCategoriasDespesas);
    }

    private ArrayList<String> getCategoriasSelecionadas(JPanel painel) {
        ArrayList<String> selecionadas = new ArrayList<>();

        for (java.awt.Component c : painel.getComponents()) {
            if (c instanceof JCheckBox) {
                JCheckBox cb = (JCheckBox) c;
                if (cb.isSelected()) {
                    selecionadas.add(cb.getText());
                }
            }
        }

        return selecionadas;
    }

    private static JSpinner criarDateSpinner(LocalDate data) {
        Date date = Date.from(data.atStartOfDay(ZoneId.systemDefault()).toInstant());
        JSpinner spinner = new JSpinner(new SpinnerDateModel(date, null, null, java.util.Calendar.DAY_OF_MONTH));
        spinner.setEditor(new JSpinner.DateEditor(spinner, "yyyy-MM-dd"));
        return spinner;
    }

    private LocalDate getDataInicial() {
        return spinnerParaLocalDate(dataInicial);
    }

    private LocalDate getDataFinal() {
        return spinnerParaLocalDate(dataFinal);
    }

    private static LocalDate spinnerParaLocalDate(JSpinner spinner) {
        Date date = (Date) spinner.getValue();
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
}
