package com.facul.trabalhofinal;

import java.awt.BorderLayout;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;

public class ExtratoFrame extends JFrame {

    public ExtratoFrame(ControleDeDados controle) {
        setTitle("Extrato detalhado");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        add(new JScrollPane(criarTabelaExtrato(controle)), BorderLayout.CENTER);
    }

    private JTable criarTabelaExtrato(ControleDeDados controle) {
        DefaultTableModel model = new DefaultTableModel(
                new Object[]{"Data", "Tipo", "Descrição", "Categoria", "Impacto", "Saldo"},
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        ArrayList<Lancamento> todos = SortFilters.sortByDate(
                controle.getDespesas(),
                controle.getReceitas()
        );

        double saldo = 0;
        LocalDate hoje = LocalDate.now();

        for (Lancamento l : todos) {
            if (l.getDate().isAfter(hoje)) {
                continue;
            }

            double impacto = l.getValor();
            saldo += impacto;

            model.addRow(new Object[]{
                l.getDate(),
                getTipo(l),
                l.getDescricao(),
                getCategoria(l),
                String.format("%.2f", impacto),
                String.format("%.2f", saldo)
            });
        }

        return new JTable(model);
    }

    private String getTipo(Lancamento l) {
        if (l instanceof Receita) {
            return "Receita";
        }

        if (l instanceof Despesa) {
            return "Despesa";
        }

        return "";
    }

    private String getCategoria(Lancamento l) {
        if (l instanceof Receita) {
            return ((Receita) l).getCategoria();
        }

        if (l instanceof Despesa) {
            return ((Despesa) l).getCategoria();
        }

        return "";
    }
}
