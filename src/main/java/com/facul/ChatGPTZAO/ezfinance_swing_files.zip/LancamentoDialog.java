package com.facul.trabalhofinal;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

public class LancamentoDialog extends JDialog {

    private static final int LIMITE_DESCRICAO = 60;
    private static final int LIMITE_CATEGORIA = 25;

    private final ControleDeDados controle;
    private final boolean receita;

    private final JTextField txtDescricao = new JTextField();
    private final JTextField txtValor = new JTextField();
    private final JComboBox<String> comboCategoria = new JComboBox<>();
    private final JSpinner dataSpinner = criarDateSpinner(LocalDate.now());

    public LancamentoDialog(JFrame parent, ControleDeDados controle, boolean receita) {
        super(parent, receita ? "Adicionar Receita" : "Adicionar Despesa", true);
        this.controle = controle;
        this.receita = receita;

        setSize(460, 260);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));

        configurarCampos();
        carregarCategorias();

        add(criarFormulario(), BorderLayout.CENTER);
        add(criarBotoes(), BorderLayout.SOUTH);
    }

    private void configurarCampos() {
        ((AbstractDocument) txtDescricao.getDocument()).setDocumentFilter(new LimiteDocumentFilter(LIMITE_DESCRICAO));
        txtValor.setToolTipText("Exemplo: 99.90");
    }

    private JPanel criarFormulario() {
        JPanel form = new JPanel(new GridLayout(4, 2, 8, 8));

        form.add(new JLabel("Descrição (máx. 60):"));
        form.add(txtDescricao);

        form.add(new JLabel("Categoria:"));
        JPanel categoriaPanel = new JPanel(new BorderLayout(5, 0));
        categoriaPanel.add(comboCategoria, BorderLayout.CENTER);

        JButton btnNovaCategoria = new JButton("+");
        btnNovaCategoria.setToolTipText("Adicionar categoria");
        btnNovaCategoria.addActionListener(e -> adicionarCategoria());
        categoriaPanel.add(btnNovaCategoria, BorderLayout.EAST);
        form.add(categoriaPanel);

        form.add(new JLabel("Valor:"));
        form.add(txtValor);

        form.add(new JLabel("Data:"));
        form.add(dataSpinner);

        return form;
    }

    private JPanel criarBotoes() {
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton cancelar = new JButton("Cancelar");
        JButton salvar = new JButton("Salvar");

        cancelar.addActionListener(e -> dispose());
        salvar.addActionListener(e -> salvarLancamento());

        botoes.add(cancelar);
        botoes.add(salvar);

        return botoes;
    }

    private void carregarCategorias() {
        comboCategoria.removeAllItems();

        if (receita) {
            for (String c : controle.getCategoriasReceitas()) {
                comboCategoria.addItem(c);
            }
        } else {
            for (String c : controle.getCategoriasDespesas()) {
                comboCategoria.addItem(c);
            }
        }
    }

    private void adicionarCategoria() {
        JTextField campo = new JTextField();
        ((AbstractDocument) campo.getDocument()).setDocumentFilter(new LimiteDocumentFilter(LIMITE_CATEGORIA));

        int resposta = JOptionPane.showConfirmDialog(
                this,
                campo,
                "Nova categoria (máx. 25 caracteres)",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (resposta != JOptionPane.OK_OPTION) {
            return;
        }

        String novaCategoria = limparCategoria(campo.getText());

        if (novaCategoria.isBlank()) {
            JOptionPane.showMessageDialog(this, "Categoria inválida.");
            return;
        }

        try {
            if (receita) {
                controle.adicionarCategoriaReceita(novaCategoria);
            } else {
                controle.adicionarCategoriaDespesa(novaCategoria);
            }

            comboCategoria.addItem(novaCategoria);
            comboCategoria.setSelectedItem(novaCategoria);

        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void salvarLancamento() {
        String descricao = limparDescricao(txtDescricao.getText());
        String categoria = (String) comboCategoria.getSelectedItem();
        LocalDate data = spinnerParaLocalDate(dataSpinner);

        double valor;
        try {
            valor = Double.parseDouble(txtValor.getText().trim().replace(",", "."));
            valor = arredondar2(valor);

            if (valor <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Valor inválido. Informe um número maior que zero.");
            return;
        }

        try {
            if (receita) {
                controle.adicionarLancamento(new Receita(descricao, categoria, valor, data));
            } else {
                controle.adicionarLancamento(new Despesa(descricao, categoria, valor, data));
            }

            dispose();

        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private static String limparDescricao(String s) {
        if (s == null) {
            return "";
        }

        s = s.replace("\n", ". ");
        s = s.replace("\r", ". ");
        s = s.replace(";", "B===D");
        s = s.trim();

        return s.substring(0, Math.min(s.length(), LIMITE_DESCRICAO));
    }

    private static String limparCategoria(String s) {
        if (s == null) {
            return "";
        }

        s = s.replace("\n", ". ");
        s = s.replace("\r", ". ");
        s = s.replace(";", "B===D");
        s = s.trim();

        return s.substring(0, Math.min(s.length(), LIMITE_CATEGORIA));
    }

    private static double arredondar2(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }

    private static JSpinner criarDateSpinner(LocalDate data) {
        Date date = Date.from(data.atStartOfDay(ZoneId.systemDefault()).toInstant());
        JSpinner spinner = new JSpinner(new SpinnerDateModel(date, null, null, java.util.Calendar.DAY_OF_MONTH));
        JFormattedTextField textField = ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField();
        textField.setEditable(true);
        spinner.setEditor(new JSpinner.DateEditor(spinner, "yyyy-MM-dd"));
        return spinner;
    }

    private static LocalDate spinnerParaLocalDate(JSpinner spinner) {
        Date date = (Date) spinner.getValue();
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    private static class LimiteDocumentFilter extends DocumentFilter {

        private final int limite;

        LimiteDocumentFilter(int limite) {
            this.limite = limite;
        }

        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
                throws BadLocationException {

            if (string == null) {
                return;
            }

            int novoTamanho = fb.getDocument().getLength() + string.length();
            if (novoTamanho <= limite) {
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                throws BadLocationException {

            if (text == null) {
                text = "";
            }

            int novoTamanho = fb.getDocument().getLength() - length + text.length();
            if (novoTamanho <= limite) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }
}
