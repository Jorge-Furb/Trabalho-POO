package com.facul.trabalhofinal;

import java.awt.BorderLayout;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class LancamentoTablePanel extends JPanel {

    public LancamentoTablePanel(List<? extends Lancamento> lancamentos) {
        setLayout(new BorderLayout());

        DefaultTableModel model = new DefaultTableModel(
                new Object[]{"Descrição", "Categoria", "Valor", "Data"},
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        for (Lancamento l : lancamentos) {
            model.addRow(new Object[]{
                l.getDescricao(),
                getCategoria(l),
                String.format("%.2f", l.getValor()),
                l.getDate()
            });
        }

        JTable tabela = new JTable(model);
        add(new JScrollPane(tabela), BorderLayout.CENTER);
    }

    private String getCategoria(Lancamento l) {
        if (l instanceof Receita) {
            return ((Receita) l).getCategoria();
        }

        if (l instanceof Despesa) {
            return ((Despesa) l).getCategoria();
        }

        return "";
    }
}
