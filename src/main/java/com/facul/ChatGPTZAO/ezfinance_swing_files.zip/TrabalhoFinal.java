package com.facul.trabalhofinal;

public class TrabalhoFinal {

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            CarregarDados dados = new CarregarDados();
            new MainFrame(dados).setVisible(true);
        });
    }
}
